const desc = document.getElementById('desc');
const amount = document.getElementById('amount');
const category = document.getElementById('category');
const addBtn = document.getElementById('addBtn');
const expenseList = document.getElementById('expenseList');
const totalAmt = document.getElementById('totalAmt');

let expenses = [];

// Load from localStorage if available
if (localStorage.getItem('expenses')) {
  try {
    expenses = JSON.parse(localStorage.getItem('expenses'));
  } catch(e) {
    expenses = [];
  }
  render();
}

addBtn.addEventListener('click', () => {
  const d = desc.value.trim();
  const a = parseFloat(amount.value);
  const c = category.value;
  if (!d || isNaN(a) || a <= 0) {
    alert('Please enter valid description and amount');
    return;
  }
  const item = { id: Date.now(), desc: d, amount: a, category: c };
  expenses.push(item);
  saveAndRender();
  desc.value=''; amount.value=''; category.value='Food';
});

function saveAndRender() {
  localStorage.setItem('expenses', JSON.stringify(expenses));
  render();
}

function render(){
  expenseList.innerHTML = '';
  let total = 0;
  expenses.forEach(e=>{
    total += e.amount;
    const li = document.createElement('li');
    li.className = 'exp-item';
    li.innerHTML = `
      <div class="exp-left">
        <div class="exp-desc">${escapeHtml(e.desc)}</div>
        <div class="exp-cat">${e.category}</div>
      </div>
      <div class="exp-right">
        <div class="exp-amt">₹${e.amount.toFixed(2)}</div>
        <button class="del-btn" data-id="${e.id}">Delete</button>
      </div>
    `;
    expenseList.appendChild(li);
  });
  totalAmt.textContent = '₹' + total.toFixed(2);
  // attach delete handlers
  document.querySelectorAll('.del-btn').forEach(b=>{
    b.addEventListener('click', (ev)=>{
      const id = Number(ev.target.getAttribute('data-id'));
      expenses = expenses.filter(x=>x.id !== id);
      saveAndRender();
    });
  });
}

function escapeHtml(unsafe) {
  return unsafe.replace(/[&<"'>]/g, function(m){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":"&#039;"}[m]; });
}
