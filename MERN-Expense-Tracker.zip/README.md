# MERN-Expense-Tracker (Mini Project - Frontend only)

Simple frontend-only Expense Tracker to demonstrate basic web skills.

## Features
- Add expense (description, category, amount)
- Delete expense
- Shows total amount
- Saves data in browser localStorage (no server required)

## How to use
1. Open `index.html` in a browser.
2. Add expenses using the form.
3. Delete any expense using the Delete button.
4. Total updates automatically.

---

**Created by:** Vedanti Shende
**For:** Resume / GitHub showcase
